# Touko 本地存储快照

拍摄时间：2026-11-12 08:33:27（Asia/Shanghai）

这是 Touko（OpenMausBot 运行时）的本地数据目录快照，包含 Bot 配置、对话记录（sqlite）、任务分派、记忆和工作区文件。用来在另一台机器上恢复这次评测的进度。

## 恢复方法

1. 先停掉 Touko 服务，避免覆盖正在写入的数据库。
2. 把包里的 `openmausbot/` 整个目录复制到目标机器的 Touko 数据目录：
   - 若从源码跑开发服务，默认数据目录是 Touko 源码旁边的 `.runtime/openmausbot`（评测环境里是 `/workspace/dev-env/.runtime/openmausbot`，由 `OMB_DATA_DIR` 指定）。
   - 如果你自己设置了 `OMB_DATA_DIR`，复制到那个目录。
3. 复制后即可重新启动 Touko。对话、Bot 和任务记录应还在。
4. 这个精简包不含 `checkpoints/` 和 `native/` 缓存，体积较小，足够查看对话、任务和记忆。完整检查点仍留在评测机上，需要的话再另要。

## 本快照未包含或需要另备的内容

- 进程锁、`*.db-shm` / `*.db-wal`（数据库已用一致备份写入 `messages.db` 和 `runtime.db`）
- `native/` 缓存
- API Key、Cursor 登录态：配置里没有写入密钥；新机器需要重新 `cursor-agent login`，中转站密钥仍用环境变量，不要把密钥提交进仓库
- 游戏仓库是另一份代码，请从 https://github.com/Alicecooo/Toukohub 拉取

注意：这里有完整对话记录，请只在本地排查使用，不要再把它推到公开仓库。
