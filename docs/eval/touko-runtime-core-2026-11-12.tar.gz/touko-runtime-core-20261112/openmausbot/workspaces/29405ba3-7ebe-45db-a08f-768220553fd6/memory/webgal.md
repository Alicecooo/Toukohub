---
title: webgal
aliases: [touko-galgame, Toukohub, galgame, touko-galgame-stress]
---

- 2026-11-11 · from chat "【纠正返工-只提交现有进度-勿另起炉灶】模型：Cursor Auto（禁止中转站/gpt-6-luna）。 唯一工作区：" · On 2026-11-11, WebGAL app/engine domain was locally committed at 7c8346c2e475799dc52d4b505b068b45ab4948b5 on main in /workspace/touko-galgame-stress (parent 6baa342 Writer scenes). Commit excludes docs/PROJECT.md and public/game/scene/**. Engine 4.6.6, base /Toukohub/.
